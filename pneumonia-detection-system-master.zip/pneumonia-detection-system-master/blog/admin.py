from django.contrib import admin
from .models import Tags,Category,Blog

admin.site.register([Tags,Category,Blog])

# Register your models here.
