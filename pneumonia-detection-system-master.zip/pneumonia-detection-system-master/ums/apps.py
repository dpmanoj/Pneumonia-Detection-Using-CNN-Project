from django.apps import AppConfig


class UmsConfig(AppConfig):
    name = 'ums'
