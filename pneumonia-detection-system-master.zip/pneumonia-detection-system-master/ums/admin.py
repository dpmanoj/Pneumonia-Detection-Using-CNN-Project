from django.contrib import admin
from .models import Normal_User,User_Support_Ticket

admin.site.register([Normal_User,User_Support_Ticket])

# Register your models here.
