from django.apps import AppConfig


class DiagnoseConfig(AppConfig):
    name = 'diagnose'
