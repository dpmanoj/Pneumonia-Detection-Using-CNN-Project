from django.apps import AppConfig


class ImsConfig(AppConfig):
    name = 'ims'
